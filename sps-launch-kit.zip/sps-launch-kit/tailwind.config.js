// Configuración de Tailwind CSS
