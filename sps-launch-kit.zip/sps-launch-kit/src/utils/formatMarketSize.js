// Función de estimación simple de tamaño de mercado
