// Página de resultados visuales
