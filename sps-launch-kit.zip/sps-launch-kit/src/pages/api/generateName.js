// API para generar nombres con OpenAI
