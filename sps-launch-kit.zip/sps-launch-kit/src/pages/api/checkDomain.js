// API para validar disponibilidad de dominio
