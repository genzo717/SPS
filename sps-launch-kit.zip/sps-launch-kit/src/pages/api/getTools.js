// API que retorna herramientas desde JSON
