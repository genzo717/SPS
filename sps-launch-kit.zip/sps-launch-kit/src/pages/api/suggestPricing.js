// API para sugerencias de pricing
