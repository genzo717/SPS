// Tarjeta de herramienta sugerida
