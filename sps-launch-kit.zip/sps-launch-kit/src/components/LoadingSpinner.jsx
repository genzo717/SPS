// Componente de loading animado
