// Componente de layout general
