// Render visual de resultados
