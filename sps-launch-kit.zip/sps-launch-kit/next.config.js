// Configuración Next.js
